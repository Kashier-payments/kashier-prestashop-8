<?php
/**
* 2007-2021 PrestaShop
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author    PrestaShop SA <contact@prestashop.com>
*  @copyright 2007-2021 PrestaShop SA
*  @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*/

if (!defined('_PS_VERSION_')) {
    exit;
}

class Kashier extends PaymentModule
{
    protected $_html = '';
    protected $output = null;
    protected $_postErrors = array();

    public $details;
    public $owner;
    public $address;
    public $extra_mail_vars;
    public $testMode = true;

    public function __construct()
    {
        $this->name = 'kashier';
        $this->tab = 'payments_gateways';
        $this->version = '1.0.0';
        $this->author = 'Kashier';
        $this->need_instance = 1;

        $this->ps_versions_compliancy = [
            'min' => '1.7',
            'max' => _PS_VERSION_
        ];
        $this->is_eu_compatible = 1;

        $this->currencies = true;
        $this->currencies_mode = 'checkbox';

        $this->bootstrap = true;
        parent::__construct();

        $this->displayName = $this->l('Kashier');
        $this->description = $this->l('Create seamless checkout experience for your customers.');
        $this->confirmUninstall = $this->l('Are you sure you want to uninstall ?');

        if (!count(Currency::checkPaymentCurrencies($this->id))) {
            $this->warning = $this->l('No currency has been set for this module.');
        }
    }

    /**
     * Don't forget to create update methods if needed:
     * http://doc.prestashop.com/display/PS16/Enabling+the+Auto-Update
     */
    public function install()
    {
        if (extension_loaded('curl') == false)
        {
            $this->_errors[] = $this->l('You have to enable the cURL extension on your server to install this module');
            return false;
        }

   

        Configuration::updateValue('KASHIER_LIVE_MODE', false);

        return parent::install() &&
            $this->registerHook('payment') &&
            $this->registerHook('paymentReturn') &&
            $this->registerHook('paymentOptions') &&
            $this->registerHook('displayPayment') &&
            $this->registerHook('displayPaymentReturn');
    }
    public function uninstall()
    {
        if (
            !Configuration::deleteByName('MERCHANT_ID')
            || !Configuration::deleteByName('TEST_API_KEY')
            || !Configuration::deleteByName('LIVE_API_KEY')
            || !Configuration::deleteByName('TEST_MODE')
            || !Configuration::deleteByName('KASHIER_CALL_TO_ACTION')
            || !Configuration::deleteByName('AR_KASHIER_CALL_TO_ACTION')
            || !Configuration::deleteByName('SUCCESS_STATE')
            || !Configuration::deleteByName('ERROR_STATE')
            || !parent::uninstall()
        )
            return false;
        return true;
    }

    public function checkCurrency($cart)
    {
        $currency_order = new Currency($cart->id_currency);
        $currencies_module = $this->getCurrency($cart->id_currency);

        if (is_array($currencies_module)) {
            foreach ($currencies_module as $currency_module) {
                if ($currency_order->id == $currency_module['id_currency']) {
                    return true;
                }
            }
        }
        return false;
    }

    //init config  page 
    public function getContent()
    {

        if (Tools::isSubmit('submit' . $this->name)) {
            $myMerchantId = strval(Tools::getValue('MERCHANT_ID'));
            $this->_postValidation();
            if (!count($this->_postErrors)) {
                $this->_postProcess();
                $this->output .= $this->displayConfirmation($this->l('Merchant Data updated'));
            } else
            $this->output .= $this->displayError($this->_postErrors[0]);
        }
        $this->output .= $this->display(__FILE__, 'infos.tpl');
        return  $this->output . $this->displayForm();
    }

    public function displayForm()
    {
        // Get default language
        $defaultLang = (int) Configuration::get('PS_LANG_DEFAULT');

        $states = new OrderState(1);
        $states2 = $states->getOrderStates(1);
        // print_r($states2);
        // die;
        // Init Fields form array
        $fieldsForm[0]['form'] = [
            'legend' => [
                'title' => $this->l('Merchant details'),
                'icon' => 'icon-cogs'
            ],
            'input' => [
                [
                    'type' => 'text',
                    'label' => $this->l('Merchant Id'),
                    'name' => 'MERCHANT_ID',
                    'placeholder' => 'Enter your Merchant ID',
                    'size' => 20,
                    'required' => true
                ],
                [
                    'type' => 'text',
                    'label' => $this->l('Test API Key For IFrame'),
                    'placeholder' => 'Enter your test API Key For IFrame',
                    'name' => 'TEST_API_KEY',
                    'size' => 20,
                    'required' => true
                ],
                [
                    'type' => 'text',
                    'label' => $this->l('Live API Key For IFrame'),
                    'placeholder' => 'Enter your live API Key For IFrame',
                    'name' => 'LIVE_API_KEY',
                    'size' => 20
                ],
                [
                    'type' => 'checkbox',
                    'label' => $this->l('Card'),
                    'name' => 'CARD_METHOD',
                    'desc' => $this->l('Accept your payments by card'),
                    'checked' => 'checked',
                    'values' => array(
                        'query' => array(
                            array(
                                'id' => 'on',
                                'val' => '1',
                                'checked' => 'checked',
                                'name' => ''
                            ),
                        ),
                        'id' => 'id',
                        'name' => 'name'
                    )
                ],
                [
                    'type' => 'checkbox',
                    'label' => $this->l('Wallet'),
                    'name' => 'WALLET_METHOD',
                    'desc' => $this->l('Accept your payments by Wallet'),
                    'checked' => 'checked',
                    'values' => array(
                        'query' => array(
                            array(
                                'id' => 'on',
                                'val' => '1',
                                'checked' => 'checked',
                                'name' => ''
                            ),
                        ),
                        'id' => 'id',
                        'name' => 'name'
                    )
                ],
                [
                    'type' => 'checkbox',
                    'label' => $this->l('Bank Installment'),
                    'name' => 'BANK_INSTALLMENT_METHOD',
                    'desc' => $this->l('Accept your payments by Bank Installment'),
                    'checked' => 'checked',
                    'values' => array(
                        'query' => array(
                            array(
                                'id' => 'on',
                                'val' => '1',
                                'checked' => 'checked',
                                'name' => ''
                            ),
                        ),
                        'id' => 'id',
                        'name' => 'name'
                    )
                ],
                [
                    'type' => 'select',
                    'label' => $this->l('Payment Success State'),
                    'name' => 'SUCCESS_STATE',
                    'required' => true,
                    'options' => array(
                        'query' => $states2,
                        'id' => 'id_order_state',
                        'name' => 'name'
                    )
                ],
                [
                    'type' => 'select',
                    'label' => $this->l('Payment Error State'),
                    'name' => 'ERROR_STATE',
                    'required' => true,
                    'options' => array(
                        'query' => $states2,
                        'id' => 'id_order_state',
                        'name' => 'name'
                    )
                ],
                [
                    'type' => 'checkbox',
                    'label' => $this->l('Test Mode'),
                    'name' => 'TEST_MODE',
                    'values' => array(
                        'query' => array(
                            array(
                                'id' => 'on',
                                'val' => '1',
                                'checked' => 'checked',
                                'name' => ''

                            ),
                        ),
                        'id' => 'id',
                        'name' => 'name'
                    )
                ],
            ],
            'submit' => [
                'title' => $this->l('Save'),
                'class' => 'btn btn-default pull-right'
            ]
        ];

        $helper = new HelperForm();

        // Module, token and currentIndex
        $helper->module = $this;
        $helper->name_controller = $this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->currentIndex = AdminController::$currentIndex . '&configure=' . $this->name;

        // Language
        $helper->default_form_language = $defaultLang;
        $helper->allow_employee_form_lang = $defaultLang;

        // Title and toolbar
        $helper->title = $this->displayName;
        $helper->show_toolbar = true;        // false -> remove toolbar
        $helper->toolbar_scroll = true;      // yes - > Toolbar is always visible on the top of the screen.
        $helper->submit_action = 'submit' . $this->name;
        $helper->toolbar_btn = [
            'save' => [
                'desc' => $this->l('Save'),
                'href' => AdminController::$currentIndex . '&configure=' . $this->name . '&save' . $this->name .
                    '&token=' . Tools::getAdminTokenLite('AdminModules'),
            ],
            'back' => [
                'href' => AdminController::$currentIndex . '&token=' . Tools::getAdminTokenLite('AdminModules'),
                'desc' => $this->l('Back to list')
            ]
        ];

        //load config data
        $helper->fields_value['MERCHANT_ID'] = Configuration::get('MERCHANT_ID');
        $helper->fields_value['TEST_MODE_on'] = Configuration::get('TEST_MODE');
        $helper->fields_value['TEST_API_KEY'] = Configuration::get('TEST_API_KEY');
        $helper->fields_value['LIVE_API_KEY'] = Configuration::get('LIVE_API_KEY');
        $helper->fields_value['CARD_METHOD_on'] = Configuration::get('CARD_METHOD');
        $helper->fields_value['WALLET_METHOD_on'] = Configuration::get('WALLET_METHOD');
        $helper->fields_value['BANK_INSTALLMENT_METHOD_on'] = Configuration::get('BANK_INSTALLMENT_METHOD');
        $helper->fields_value['SUCCESS_STATE'] = Configuration::get('SUCCESS_STATE') ? Configuration::get('SUCCESS_STATE') : 2;
        $helper->fields_value['ERROR_STATE'] = Configuration::get('ERROR_STATE') ? Configuration::get('ERROR_STATE') : 8;


        return $helper->generateForm($fieldsForm);
    }

    // config fields vakidation
    protected function _postValidation()
    {
        if (!Tools::getValue('MERCHANT_ID'))
            $this->_postErrors[] = $this->l('Merchant id is required.');
        elseif (!Tools::getValue('TEST_API_KEY') && Tools::getValue('TEST_MODE_on'))
            $this->_postErrors[] = $this->l('Test API key is required.');
        elseif (!Tools::getValue('LIVE_API_KEY') && !Tools::getValue('TEST_MODE_on'))
            $this->_postErrors[] = $this->l('Live API key is required in live mode.');
        elseif(!Tools::getValue('CARD_METHOD_on') && !Tools::getValue('WALLET_METHOD_on') && !Tools::getValue('BANK_INSTALLMENT_METHOD_on'))
            $this->_postErrors[] = $this->l('At least one payment method is required');
    }

    // handle config post 
    protected function _postProcess()
    {
        Configuration::updateValue('MERCHANT_ID', Tools::getValue('MERCHANT_ID'));
        Configuration::updateValue('TEST_MODE', Tools::getValue('TEST_MODE_on'));
        Configuration::updateValue('TEST_API_KEY', Tools::getValue('TEST_API_KEY'));
        Configuration::updateValue('LIVE_API_KEY', Tools::getValue('LIVE_API_KEY'));
        Configuration::updateValue('CARD_METHOD', Tools::getValue('CARD_METHOD_on'));
        Configuration::updateValue('WALLET_METHOD', Tools::getValue('WALLET_METHOD_on'));
        Configuration::updateValue('BANK_INSTALLMENT_METHOD', Tools::getValue('BANK_INSTALLMENT_METHOD_on'));
        Configuration::updateValue('SUCCESS_STATE', Tools::getValue('SUCCESS_STATE'));
        Configuration::updateValue('ERROR_STATE', Tools::getValue('ERROR_STATE'));

    }
    /**
     * This method is used to render the payment button,
     * Take care if the button should be displayed or not.
     */
    public function hookPayment($params)
    {
        $currency_id = $params['cart']->id_currency;
        $currency = new Currency((int)$currency_id);

        if (in_array($currency->iso_code, $this->limited_currencies) == false)
            return false;

        $this->smarty->assign('module_dir', $this->_path);

        return $this->display(__FILE__, 'views/templates/hook/payment.tpl');
    }
    
    /**
     * Return payment options available for PS 1.7+
     *
     * @param array Hook parameters
     *
     * @return array|null
     */
    public function hookPaymentOptions($params)
    {
        if (!$this->active) {
            return;
        }
        if (!$this->checkCurrency($params['cart'])) {
            return;
        }
        $paymentOptions = [];
        
        if(Configuration::get('CARD_METHOD'))
        $paymentOptions[] = $this->getCreditCardPaymentOption();
        if(Configuration::get('BANK_INSTALLMENT_METHOD'))
        $paymentOptions[] = $this->getInstallmentPaymentOption();
        if(Configuration::get('WALLET_METHOD'))
        $paymentOptions[] = $this->getWalletPaymentOption();
        
        return $paymentOptions;
    }

    public function getCreditCardPaymentOption()
    {
        $methodOption = new \PrestaShop\PrestaShop\Core\Payment\PaymentOption();
        $methodOption->setCallToActionText(($this->context->language->iso_code == 'ar' || $this->context->language->iso_code == 'eg-ar' ) ? 'الدفع بواسطة الكارت' : 'Pay by card')
               ->setAction($this->context->link->getModuleLink($this->name, 'card', [], true));
 
        return $methodOption;
    }

    public function getWalletPaymentOption()
    {
        $methodOption = new \PrestaShop\PrestaShop\Core\Payment\PaymentOption();
        $methodOption->setCallToActionText(($this->context->language->iso_code == 'ar' || $this->context->language->iso_code == 'eg-ar' ) ? 'المحفظة الالكترونية' : 'Wallet')
               ->setAction($this->context->link->getModuleLink($this->name, 'wallet', [], true));
 
        return $methodOption;
    }
    public function getInstallmentPaymentOption()
    {
        $methodOption = new \PrestaShop\PrestaShop\Core\Payment\PaymentOption();
        $methodOption->setCallToActionText(($this->context->language->iso_code == 'ar' || $this->context->language->iso_code == 'eg-ar' ) ? 'تقسيط البنك' : 'Bank Installment')
               ->setAction($this->context->link->getModuleLink($this->name, 'installment', [], true));
 
        return $methodOption;
    }

    // payment return from iframe and validation
    public function hookPaymentReturn($params)
    {
        if ($this->active == false)
            return;

        $order = $params['objOrder'];

        if ($order->getCurrentOrderState()->id != Configuration::get('PS_OS_ERROR'))
            $this->smarty->assign('status', 'ok');

        $this->smarty->assign(array(
            'id_order' => $order->id,
            'reference' => $order->reference,
            'params' => $params,
            'total' => Tools::displayPrice($params['total_to_pay'], $params['currencyObj'], false),
        ));
        return $this->display(__FILE__, 'payment_return.tpl');
    }

    // public function hookOrderConfirmation($params)
    // {
    //     $objOrder = $params['objOrder'];
    //     $history = new OrderHistory();
    //     $history->id_order = (int) $objOrder->id;
    //     $history->changeIdOrderState((int) Configuration::get('SUCCESS_STATE'), (int) ($objOrder->id), true);
    //     $history->save();
    // }
    public function hookDisplayPayment()
    {
        /* Place your code here. */
    }

    public function hookDisplayPaymentReturn()
    {
        /* Place your code here. */
    }
}
